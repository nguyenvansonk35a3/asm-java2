package AsignmentJava2;

import java.awt.Color;
import java.awt.HeadlessException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class QLNV extends javax.swing.JFrame implements Runnable {

    NhanVien nhanvien = null;
    List<NhanVien> list = new ArrayList<>();
    DefaultTableModel model;

    public QLNV() {
        initComponents();
        this.setLocationRelativeTo(null);
        combobox();

        Thread t1 = new Thread(this);
        t1.start();
        btnClock.setEnabled(true);
    }

    @Override
    public void run() {
        while (true) {
            try {
                Date now = new Date();
                SimpleDateFormat formater = new SimpleDateFormat();
                formater.applyPattern("hh:mm:ss aa");
                String time = formater.format(now);
                btnClock.setText(time);
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                JOptionPane.showMessageDialog(null, "Error!");
            }
        }
    }

    private void combobox() {
        DefaultComboBoxModel cbo = new DefaultComboBoxModel();
        cbo.removeAllElements();
        cbo.addElement("CNTT");
        cbo.addElement("DU LICH");
        cbo.addElement("WEBSITE");
        cbo.addElement("DESIGN");

        cboPhongBan.setModel(cbo);
    }

    public void newMoi() {
        txtmaNhanVien.setText(null);
        txtHoTen.setText(null);
        txtTuoi.setText(null);
        txtEmail.setText(null);
        txtLuong.setText(null);
    }

    public void add() {
        nhanvien = new NhanVien();

        //dat ten bien
        String maNhanVien = txtmaNhanVien.getText();
        String Hoten = txtHoTen.getText();
        String Tuoi = txtTuoi.getText();
        String Email = txtEmail.getText();
        String Luong = txtLuong.getText();

        try {
            nhanvien.maNV = txtmaNhanVien.getText();
            if (nhanvien.maNV.length() == 0) {
                JOptionPane.showMessageDialog(this, "ma null");
                txtmaNhanVien.setBackground(Color.red);
                return;
            }
            if (kiemtraTrung(maNhanVien) == true) {
                JOptionPane.showMessageDialog(this, "ma NV da ton tai!");
                txtmaNhanVien.setBackground(Color.yellow);
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.toString());
        }

        try {
            nhanvien.name = txtHoTen.getText();
            if (Hoten.length() == 0) {
                JOptionPane.showMessageDialog(this, "ten null");
                txtHoTen.setBackground(Color.red);
                return;
            }

            String reTen = "[a-zA-Z ]+";
            if (!txtHoTen.getText().matches(reTen)) {
                JOptionPane.showMessageDialog(this, "lỗi tên");
                txtHoTen.setBackground(Color.yellow);
                return;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, e.toString());
        }

        try {
            if (Tuoi.length() == 0) {
                JOptionPane.showMessageDialog(this, "tuoi null");
                txtTuoi.setBackground(Color.red);
                return;
            }
            try {
                Integer so = Integer.parseInt(Tuoi);
                if (so < 16 || so > 55) {
                    JOptionPane.showMessageDialog(this, "tuoi phai tu 16 den 55");
                    txtTuoi.setBackground(Color.yellow);
                    return;
                }
            } catch (HeadlessException | NumberFormatException e) {
                txtTuoi.setBackground(Color.red);
            }

            nhanvien.tuoi = Integer.parseInt(txtTuoi.getText());

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, " exception tuoi");
            return;
        }

        try {
            nhanvien.email = txtEmail.getText();
            if (Email.length() == 0) {
                JOptionPane.showMessageDialog(this, "email null");
                txtEmail.setBackground(Color.red);
                return;
            }
            try {
                String reEmail = "\\w+@\\w+(\\.\\w+){1,2}";
                if (!Email.matches(reEmail)) {
                    JOptionPane.showMessageDialog(this, "Email không hợp lệ");
                    txtEmail.setBackground(Color.red);
                    return;
                }
            } catch (HeadlessException e) {
                txtEmail.setBackground(Color.pink);
            }

        } catch (Exception e) {
        }

        nhanvien.phongBan = cboPhongBan.getSelectedItem().toString();

        try {
            if (Luong.length() == 0) {
                JOptionPane.showMessageDialog(this, "luong null");
                txtLuong.setBackground(Color.red);
                return;
            }
            try {
                Integer salary = Integer.parseInt(Luong);
                if (salary < 5E6) {
                    JOptionPane.showMessageDialog(this, "Lương phải trên 5 triệu!");
                    txtLuong.setBackground(Color.yellow);
                    return;
                }
            } catch (HeadlessException | NumberFormatException e) {
                txtLuong.setBackground(Color.pink);
            }
            nhanvien.luong = Integer.parseInt(txtLuong.getText());

        } catch (Exception e) {
        }

        list.add(nhanvien);
    }

    public void hienThi() {
        model = (DefaultTableModel) tblTable.getModel();
        model.setRowCount(0);
        for (NhanVien nv : list) {
            Object[] row = new Object[]{
                nv.maNV, nv.name, nv.tuoi, nv.email, nv.phongBan, nv.luong
            };
            model.addRow(row);
        }
    }

    public boolean kiemtraTrung(String ma) {
        boolean trave = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).maNV.equals(ma)) {
                trave = true;
            }
        }
        return trave;
    }

    public void delete() {
        int xoa = tblTable.getSelectedRow();
        list.remove(xoa);
    }

    public void save() {
        FileOutputStream fos = null;
        ObjectOutputStream oos = null;
        try {
            fos = new FileOutputStream("D:\\Java2Asignment\\data.txt");
            oos = new ObjectOutputStream(fos);
            oos.writeObject(list);
            JOptionPane.showMessageDialog(this, "Luu thanh cong!");
            oos.close();
            fos.close();
        } catch (FileNotFoundException ex) {
            Logger.getLogger(QLNV.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(QLNV.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    //showItems
    public void showItems(int index) {
        nhanvien = list.get(index);
        txtmaNhanVien.setText(nhanvien.maNV);
        txtHoTen.setText(nhanvien.name);
        txtTuoi.setText(String.valueOf(nhanvien.tuoi));
        txtEmail.setText(nhanvien.email);
        nhanvien.phongBan = (String) cboPhongBan.getSelectedItem();
        txtLuong.setText(String.valueOf(nhanvien.maNV));
    }

    public void first() {
        showItems(0);
    }

    int bienLui = 0;

    public void lui() {
        bienLui--;
        if (bienLui < 0) {
            bienLui = 0;
        }
        showItems(bienLui);
    }

    public void next() {
        bienLui++;
        if (bienLui > list.size() - 1) {
            bienLui = list.size() - 1;
        }
        showItems(bienLui);
    }

    public void last() {
        showItems(list.size() - 1);
    }

    //OpenFile
    public void openFile() throws FileNotFoundException, IOException {
        try {
            FileInputStream fis = new FileInputStream("D:\\Java2Asignment\\data.txt");
            ObjectInputStream ois = new ObjectInputStream(fis);
            list = (ArrayList) ois.readObject();
            fis.close();
            ois.close();
        } catch (ClassNotFoundException e) {
            System.out.println("Class not found");
        } catch (IOException ex) {
            System.out.println("Error Read File");
        }
    }

    //show detai
    public void showDetai() {
        txtmaNhanVien.setText(model.getValueAt(tblTable.getSelectedRow(), 0).toString());
        txtHoTen.setText(model.getValueAt(tblTable.getSelectedRow(), 1).toString());
        txtTuoi.setText(model.getValueAt(tblTable.getSelectedRow(), 2).toString());
        txtEmail.setText(model.getValueAt(tblTable.getSelectedRow(), 3).toString());
        cboPhongBan.setToolTipText(model.getValueAt(tblTable.getSelectedRow(), 4).toString());
        txtLuong.setText(model.getValueAt(tblTable.getSelectedRow(), 5).toString());
    }

    public void find() {
        model.setRowCount(0);
        ArrayList<NhanVien> ds = new ArrayList<>();
        try {
            if (txtFind.getText().length() != 0) {
                for (NhanVien v : list) {
                    if (v.getMaNV().toLowerCase().matches(txtFind.getText())) {
                        ds.add(v);
                    }
                }
                if (ds.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Khong tim thay!");
                } else {
                    for (NhanVien v : ds) {
                        Object[] row = new Object[]{
                            v.maNV, v.name, v.tuoi, v.email, v.phongBan, v.luong
                        };
                        model.addRow(row);
                    }
                    JOptionPane.showMessageDialog(this, "tim kiem thanh cong ma so " + txtFind.getText());
                }
            } else {
                JOptionPane.showMessageDialog(this, "Nhap thong tin de tim kiem!");
            }
        } catch (Exception e) {
        }
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        lblIMG = new javax.swing.JLabel();
        btnShow = new javax.swing.JToggleButton();
        btnHidden = new javax.swing.JToggleButton();
        jLabel2 = new javax.swing.JLabel();
        lbladmin = new javax.swing.JLabel();
        lblbirthday = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblcompany = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        lblwebsite = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        txtmaNhanVien = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        txtHoTen = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTuoi = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtEmail = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txtLuong = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        cboPhongBan = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblTable = new javax.swing.JTable();
        btnNew = new javax.swing.JToggleButton();
        btnAdd = new javax.swing.JToggleButton();
        btnDelete = new javax.swing.JToggleButton();
        btnSave = new javax.swing.JToggleButton();
        btnOpen = new javax.swing.JToggleButton();
        btnExit = new javax.swing.JToggleButton();
        btnFirst = new javax.swing.JToggleButton();
        btnLui = new javax.swing.JToggleButton();
        btnNext = new javax.swing.JToggleButton();
        btnLast = new javax.swing.JToggleButton();
        btnFind = new javax.swing.JToggleButton();
        txtFind = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        btnClock = new javax.swing.JToggleButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createCompoundBorder());

        lblIMG.setIcon(new javax.swing.ImageIcon("D:\\Java2Asignment\\IMG\\img123.JPG")); // NOI18N

        btnShow.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnShow.setText("Show");
        btnShow.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnShowActionPerformed(evt);
            }
        });

        btnHidden.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnHidden.setText("Hidden");
        btnHidden.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnHiddenActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel2.setText("admin:");

        lbladmin.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lbladmin.setText(". . . ");
        lbladmin.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                lbladminAncestorAdded(evt);
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });

        lblbirthday.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblbirthday.setText(". . . ");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel5.setText("birthday:");

        lblcompany.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblcompany.setText(". . . ");

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel7.setText("company:");

        lblwebsite.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        lblwebsite.setText(". . . ");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel9.setText("website:");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING)
                                        .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING))
                                    .addComponent(jLabel9))
                                .addGap(112, 112, 112)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblcompany)
                                    .addComponent(lbladmin)
                                    .addComponent(lblbirthday)
                                    .addComponent(lblwebsite)))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(15, 15, 15)
                                .addComponent(btnShow)
                                .addGap(77, 77, 77)
                                .addComponent(btnHidden))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(39, 39, 39)
                        .addComponent(lblIMG)))
                .addContainerGap(32, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblIMG)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnShow)
                    .addComponent(btnHidden))
                .addGap(37, 37, 37)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(lbladmin))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(lblbirthday))
                .addGap(26, 26, 26)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(lblcompany))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(lblwebsite))
                .addGap(165, 165, 165))
        );

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel4.setText("MA NHAN VIEN:");

        txtmaNhanVien.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel6.setText("HO TEN:");

        txtHoTen.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel8.setText("TUOI:");

        txtTuoi.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel10.setText("EMAIL:");

        txtEmail.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel11.setText("LUONG:");

        txtLuong.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel12.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        jLabel12.setText("PHONG BAN:");

        cboPhongBan.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        tblTable.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        tblTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "MA", "TEN", "TUOI", "EMAIL", "PHONG BAN", "LUONG"
            }
        ));
        tblTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblTableMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblTable);

        btnNew.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnNew.setText("NEW");
        btnNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewActionPerformed(evt);
            }
        });

        btnAdd.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnAdd.setText("ADD");
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });

        btnDelete.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnDelete.setText("DELETE");
        btnDelete.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteActionPerformed(evt);
            }
        });

        btnSave.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnSave.setText("SAVE");
        btnSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSaveActionPerformed(evt);
            }
        });

        btnOpen.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnOpen.setText("OPEN");
        btnOpen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOpenActionPerformed(evt);
            }
        });

        btnExit.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnExit.setText("EXIT");
        btnExit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnExitActionPerformed(evt);
            }
        });

        btnFirst.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnFirst.setText("<<");
        btnFirst.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFirstActionPerformed(evt);
            }
        });

        btnLui.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnLui.setText("<");
        btnLui.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLuiActionPerformed(evt);
            }
        });

        btnNext.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnNext.setText(">");
        btnNext.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNextActionPerformed(evt);
            }
        });

        btnLast.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnLast.setText(">>");
        btnLast.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnLastActionPerformed(evt);
            }
        });

        btnFind.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        btnFind.setText("FIND");
        btnFind.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFindActionPerformed(evt);
            }
        });

        txtFind.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1)
                .addContainerGap())
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel12)
                    .addComponent(jLabel4)
                    .addComponent(jLabel6)
                    .addComponent(jLabel8)
                    .addComponent(jLabel10)
                    .addComponent(jLabel11))
                .addGap(64, 64, 64)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnNew)
                        .addGap(18, 18, 18)
                        .addComponent(btnAdd)
                        .addGap(18, 18, 18)
                        .addComponent(btnDelete)
                        .addGap(18, 18, 18)
                        .addComponent(btnSave)
                        .addGap(18, 18, 18)
                        .addComponent(btnOpen)
                        .addGap(18, 18, 18)
                        .addComponent(btnExit)
                        .addContainerGap(25, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(txtLuong)
                            .addComponent(txtEmail)
                            .addComponent(txtTuoi)
                            .addComponent(txtmaNhanVien, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtHoTen, javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cboPhongBan, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(30, 30, 30))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(btnFind)
                .addGap(18, 18, 18)
                .addComponent(txtFind, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnFirst)
                .addGap(44, 44, 44)
                .addComponent(btnLui)
                .addGap(44, 44, 44)
                .addComponent(btnNext)
                .addGap(36, 36, 36)
                .addComponent(btnLast)
                .addGap(28, 28, 28))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtmaNhanVien, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(11, 11, 11)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txtHoTen, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTuoi, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addGap(14, 14, 14)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtEmail, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboPhongBan, javax.swing.GroupLayout.PREFERRED_SIZE, 43, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtLuong, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnNew)
                    .addComponent(btnAdd)
                    .addComponent(btnDelete)
                    .addComponent(btnSave)
                    .addComponent(btnOpen)
                    .addComponent(btnExit))
                .addGap(27, 27, 27)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 209, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnFirst)
                    .addComponent(btnLui)
                    .addComponent(btnNext)
                    .addComponent(btnLast)
                    .addComponent(btnFind, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtFind, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(204, 0, 0));
        jLabel3.setText("QUAN LY NHAN VIEN");

        btnClock.setFont(new java.awt.Font("Tahoma", 0, 24)); // NOI18N
        btnClock.setText("Clock");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGap(118, 118, 118)
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 190, Short.MAX_VALUE)
                        .addComponent(btnClock, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(btnClock))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 737, Short.MAX_VALUE))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewActionPerformed
        // TODO add your handling code here:
        this.newMoi();
    }//GEN-LAST:event_btnNewActionPerformed

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        this.add();
        this.hienThi();
    }//GEN-LAST:event_btnAddActionPerformed

    private void btnDeleteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteActionPerformed
        this.delete();
        this.hienThi();
    }//GEN-LAST:event_btnDeleteActionPerformed

    private void btnSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSaveActionPerformed
        this.save();
    }//GEN-LAST:event_btnSaveActionPerformed

    private void btnOpenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOpenActionPerformed
        try {
            openFile();
        } catch (IOException ex) {
            Logger.getLogger(QLNV.class.getName()).log(Level.SEVERE, null, ex);
        }
        hienThi();
        try {
            showDetai();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "show thanh cong");
        }
    }//GEN-LAST:event_btnOpenActionPerformed

    private void btnExitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnExitActionPerformed
        // TODO add your handling code here:
        JOptionPane.showMessageDialog(this, "Thoat chuong trinh!");
        System.exit(0);
    }//GEN-LAST:event_btnExitActionPerformed

    private void tblTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblTableMouseClicked
        // TODO add your handling code here:
        model = (DefaultTableModel) tblTable.getModel();
        this.showDetai();
    }//GEN-LAST:event_tblTableMouseClicked

    private void btnFirstActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFirstActionPerformed
        // TODO add your handling code here:
        this.first();
    }//GEN-LAST:event_btnFirstActionPerformed

    private void btnLuiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLuiActionPerformed
        // TODO add your handling code here:
        this.lui();
    }//GEN-LAST:event_btnLuiActionPerformed

    private void btnNextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNextActionPerformed
        // TODO add your handling code here:
        this.next();
    }//GEN-LAST:event_btnNextActionPerformed

    private void btnLastActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnLastActionPerformed
        // TODO add your handling code here:
        this.last();
    }//GEN-LAST:event_btnLastActionPerformed

    private void btnShowActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnShowActionPerformed
        // TODO add your handling code here:
        lblIMG.setVisible(true);
    }//GEN-LAST:event_btnShowActionPerformed

    private void btnHiddenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnHiddenActionPerformed
        // TODO add your handling code here:
        lblIMG.setVisible(false);
    }//GEN-LAST:event_btnHiddenActionPerformed

    private void lbladminAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_lbladminAncestorAdded
        // TODO add your handling code here:
        lbladmin.setText("SONSO");
        lblbirthday.setText("1995");
        lblcompany.setText("SonSoPro");
        lblwebsite.setText("SONSO.ORG");
    }//GEN-LAST:event_lbladminAncestorAdded

    private void btnFindActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFindActionPerformed
        this.find();
    }//GEN-LAST:event_btnFindActionPerformed

    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(QLNV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(QLNV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(QLNV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(QLNV.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new QLNV().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JToggleButton btnAdd;
    private javax.swing.JToggleButton btnClock;
    private javax.swing.JToggleButton btnDelete;
    private javax.swing.JToggleButton btnExit;
    private javax.swing.JToggleButton btnFind;
    private javax.swing.JToggleButton btnFirst;
    private javax.swing.JToggleButton btnHidden;
    private javax.swing.JToggleButton btnLast;
    private javax.swing.JToggleButton btnLui;
    private javax.swing.JToggleButton btnNew;
    private javax.swing.JToggleButton btnNext;
    private javax.swing.JToggleButton btnOpen;
    private javax.swing.JToggleButton btnSave;
    private javax.swing.JToggleButton btnShow;
    private javax.swing.JComboBox<String> cboPhongBan;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblIMG;
    private javax.swing.JLabel lbladmin;
    private javax.swing.JLabel lblbirthday;
    private javax.swing.JLabel lblcompany;
    private javax.swing.JLabel lblwebsite;
    private javax.swing.JTable tblTable;
    private javax.swing.JTextField txtEmail;
    private javax.swing.JTextField txtFind;
    private javax.swing.JTextField txtHoTen;
    private javax.swing.JTextField txtLuong;
    private javax.swing.JTextField txtTuoi;
    private javax.swing.JTextField txtmaNhanVien;
    // End of variables declaration//GEN-END:variables

}
