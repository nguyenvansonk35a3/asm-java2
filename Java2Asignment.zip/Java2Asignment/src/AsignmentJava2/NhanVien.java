package AsignmentJava2;

import java.io.Serializable;

public class NhanVien implements Serializable {

    String maNV;
    String name;
    int tuoi;
    String email;
    String phongBan;
    int luong;

    public NhanVien() {
    }

    public NhanVien(String maNV, String name, int tuoi, String email, String phongBan, int luong) {
        this.maNV = maNV;
        this.name = name;
        this.tuoi = tuoi;
        this.email = email;
        this.phongBan = phongBan;
        this.luong = luong;
    }

    public String getMaNV() {
        return maNV;
    }

    public void setMaNV(String maNV) {
        this.maNV = maNV;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTuoi() {
        return tuoi;
    }

    public void setTuoi(int tuoi) {
        this.tuoi = tuoi;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhongBan() {
        return phongBan;
    }

    public void setPhongBan(String phongBan) {
        this.phongBan = phongBan;
    }

    public int getLuong() {
        return luong;
    }

    public void setLuong(int luong) {
        this.luong = luong;
    }

}
